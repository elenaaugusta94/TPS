package pacoteGlobal;

/**
 * Classe correspondente a interface do programa
 */
public class Interface {

   
    GerenciadorPessoa p = new GerenciadorPessoa();
    
    GerenciadorVeiculo v = new GerenciadorVeiculo();
	
}
